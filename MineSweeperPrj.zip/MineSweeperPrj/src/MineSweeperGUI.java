import javax.swing.*;

public class MineSweeperGUI extends JFrame {
    public MineSweeperGUI(String name) {

        //set the title of the game to the name variable
        super(name);


        //make sure the frame will close
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        try {
            String playerName = JOptionPane.showInputDialog("Please enter your name: ");
            this.setTitle(playerName + "'s Minesweeper");
            String sizeHolder = JOptionPane.showInputDialog("Please" +
                            " enter the preferred size of the board (3-30: ",
                    "10");
            int size = Integer.parseInt(sizeHolder);


            this.getContentPane().add(new MineSweeperPanel(size));
            this.setSize(10 * size, 10 * size);
            this.setVisible(true);

        } catch (Exception e) {
            System.out.println(e);
        }




    }
    @Override
    public String toString(){
        String string = new String();
        return string;
    }

    public static void main (String[]args){
        new MineSweeperGUI("Mine Sweeper!");
    }
}
