package project2;

/******************************************
 * This class will establish the individual cells, which each have their own
 * characteristics.  These include the number of mines surrounding a given cell,
 * whether it has been flagged, whether it has been clicked and exposed, or
 * whether it contains a mine, in which case the player loses.
 ******************************************/

public class Cell {
    private int mineCount;
    private boolean isFlagged;
    private boolean isExposed;
    private boolean isMine;

    /**************************
     * This is the constructor for the Cell class that establishes defaults
     * for each cell.
     **************************/
    public Cell() {
        mineCount = 0;
        isFlagged = false;
        isExposed = false;
        isMine = false;
    }

    /**************************
     * This constructor will set up each characteristic of a given cell.
     * @param mineCount the number of mines surrounding a cell
     * @param isFlagged whether or not the cell is flagged
     * @param isExposed whether or not the cell is exposed
     * @param isMine whether or not the cell has a mine
     */
    public Cell(int mineCount, boolean isFlagged,
                boolean isExposed, boolean isMine) {

        this.mineCount = mineCount;
        this.isFlagged = false;
        this.isExposed = false;
        this.isMine = false;

    }
    /******************************************************************
     * Sets the number of mines in the game to the parameter.
     * @param mineCount an int that gives the number of mines.
     *****************************************************************/
    public void setMineCount(int mineCount) {
        this.mineCount = mineCount;
    }
    /******************************************************************
     * Gets the current value of mineCount and returns it.
     * @return mineCount, An int that details the number of mines.
     *****************************************************************/
    public int getMineCount() {
        return mineCount;
    }

    /******************************************************************
     * This method will set a given cell to flagged or not-flagged.
     * @param isFlagged, the status of the flag
     ******************************************************************/
    public void setFlagged(boolean isFlagged) {
        this.isFlagged = isFlagged;
    }

    /******************************************************************
     * Gets the current state of isFlagged and returns.
     * @return isFlagged, A boolean that details if the cell
     * is flagged.
     *****************************************************************/
    public boolean isFlagged() {
        return this.isFlagged;
    }

    /******************************************************************
     * A method that accepts a boolean which changes the state of
     * IsExposed.
     * @param isExposed a boolean that says whether a cell is exposed or
     * not.
     *****************************************************************/
    public void setExposed(boolean isExposed) {
        this.isExposed = isExposed;
    }

    /******************************************************************
     * Gets the current state of isExposed and returns it.
     * @return isExposed, A boolean that details if the cell
     * is exposed.
     *****************************************************************/
    public boolean isExposed() {
        return this.isExposed;
    }

    /******************************************************************
     * Sets the current state of is mine equal to the parameter
     * @param isMine a boolean that details if the cell is a mine
     *****************************************************************/
    public void setMine(boolean isMine) {
        this.isMine = isMine;
    }

    /******************************************************************
     * Gets the current state of isMine and returns it.
     * @return isMine, A boolean that details if the cell is a mine.
     *****************************************************************/
    public boolean isMine() {
        return this.isMine;
    }

    /**************************
     * This method will swap a cell from flagged to not flagged and
     * vice-versa.
     *************************/
    public void swapFlagged() {
        this.isFlagged = !this.isFlagged;
    }

    /**************************
     * This method will place a mine onto the board.
     **************************/
    public void placeMine() {
        this.isMine = true;
    }


}
