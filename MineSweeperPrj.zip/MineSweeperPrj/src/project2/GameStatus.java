package project2;

/**
 * This enum will restrict the game status to only three states.  This
 * will help keep game integrity as well as keep it better organized.
 */
public enum GameStatus {
    Lost, Won, NotOverYet
}

