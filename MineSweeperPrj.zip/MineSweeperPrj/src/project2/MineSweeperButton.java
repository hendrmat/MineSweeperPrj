package project2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;

public class MineSweeperButton extends JButton implements ActionListener {

    public MineSweeperButton(Cell c) {

    }

    @Override
    public void actionPerformed(ActionEvent actionEvent) {

    }
}
