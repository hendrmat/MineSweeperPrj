package project2;

import javax.swing.*;
import java.awt.GridBagConstraints;
import java.awt.GridLayout;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class MineSweeperGUI extends JFrame {

    public MineSweeperGUI(String name) {

        //set the title of the game to the name variable
        super(name);

        int row = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Please select the number of rows from 3 to 30."));

        while (row < 3 || row > 30) {
            row = Integer.parseInt(JOptionPane.showInputDialog(null,
                    "Invalid number of rows.  Please try again."));
        }

        int col = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Please select the number of columns from 3 to 30."));

        while (col < 3 || col > 30) {
            col = Integer.parseInt(JOptionPane.showInputDialog(null,
                    "Invalid number of columns.  Please try again."));
        }

        int mines = Integer.parseInt(JOptionPane.showInputDialog(null,
                "Please input the number of mines."));

        while (mines < 1) {
            mines = Integer.parseInt(JOptionPane.showInputDialog(null,
                    "Please input a non-zero, non-negative number of mines."));
        }

        if (mines >= 1) {
            while (mines >= (row * col)){
                mines = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "There are too many mines for a board of that size." +
                                " Please enter a valid number of mines."));
            }
        }

        //make sure the frame will close
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        try {
            String playerName = JOptionPane.showInputDialog("Please enter your name: ");
            this.setTitle(playerName + "'s Minesweeper");
            this.getContentPane().add(new MineSweeperPanel());
            this.setSize(10 * row, 10 * col);
            this.setVisible(true);

        } catch (Exception e) {
            System.out.println(e);
        }




    }
    @Override
    public String toString(){
        String string = new String();
        return string;
    }
    public static void main (String[] args) {

        MineSweeperGUI gui = new MineSweeperGUI("MineSweeper");
        gui.setVisible(true);

    }


}
