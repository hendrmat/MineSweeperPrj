package project2;

import javax.swing.*;
import javax.swing.plaf.basic.BasicOptionPaneUI;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;


public class MineSweeperPanel extends JPanel {

    private JButton[][] board;
    private Cell iCell;
    private JButton quitButton;
    private JButton cheatButton;
    private JButton defaultButton;
    private JButton newGame;
    private JButton showCell;
    private int numRows;
    private int numCols;
    public int losses;
    public int wins;
    private MineSweeperGame game;

    //Displays wins and losses
    private JLabel lossesLabel;
    private JLabel winsLabel;

    //Image Icon for empty cells
    private ImageIcon emptyIcon;


    public void setNumRows(int numRows) {
        this.numRows = numRows;
    }

    public int getNumRows() {
        return numRows;
    }

    public void setNumCols(int numCols) {
        this.numCols = numCols;
    }

    public int getNumCols() {
        return numCols;
    }

    public int getWins() {

        return wins;
    }

    public int getLosses() {

        return losses;
    }


    public MineSweeperPanel() {
        //game = new MineSweeperGame();
        JPanel buttons = new JPanel();
        quitButton = new JButton("Quit", new ImageIcon(""));
        quitButton.add(buttons);
        cheatButton = new JButton("Cheat!", new ImageIcon(""));
        cheatButton.add(buttons);
        defaultButton = new JButton("Default Setting", new ImageIcon(""));
        defaultButton.add(buttons);
        buttons.setBackground(Color.GRAY);
        buttons.setVisible(true);


        //Wins and losses label instantiation
        this.lossesLabel = new JLabel("Losses: ");
        this.winsLabel = new JLabel("Wins: ");
        this.showCell = new JButton("Show Contents of Cell");


        JPanel gamePanel = new JPanel();
        gamePanel.setLayout(new GridLayout(numRows, numCols));
        this.add(gamePanel, BorderLayout.CENTER);

        //using Grid layout for overall panel as well
        buttons.setLayout(new GridLayout(1, 6));
        this.add(buttons, BorderLayout.SOUTH);

        //Making a button listener so the buttons actually work
        ButtonListener listener = new ButtonListener();

        //Adding the button listener to the buttons
        cheatButton.addActionListener(listener);
        showCell.addActionListener(listener);
        newGame.addActionListener(listener);
        quitButton.addActionListener(listener);

        //Adding it all to the panel
        buttons.add(newGame);
        buttons.add(quitButton);
        buttons.add(cheatButton);
        buttons.add(showCell);
        buttons.add(winsLabel);
        buttons.add(lossesLabel);


        //Sets up the board for the game
        for (int row = 0; row < 10; row++) {
            for (int col = 0; col < 10; col++) {
                board[row][col] = new JButton("", emptyIcon);
                board[row][col].addActionListener(listener);
                buttons.add(board[row][col]);
            }
        }

        board = new JButton[numRows][numCols];
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                board[i][j] = new JButton("", new ImageIcon(""));
                //board[i][j].addActionListener(this);
                gamePanel.add(board[i][j]);
            }
        }
    }

    private void displayBoard() {

        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                iCell = game.getCell(i, j);
                if (iCell.isExposed()) {
                    board[i][j].setEnabled(false);
                } else {
                    board[i][j].setEnabled(true);
                }

                if (iCell.isExposed()) {
                    board[i][j].setText("" + iCell.getMineCount());
                }
            }
        }
    }

    private class ButtonListener implements ActionListener {

        public void actionPerformed(ActionEvent e) {

            //if the button that is detected being clicked is the quit
            //button it closes everything associated with the program
            if (quitButton == e.getSource()) {
                System.exit(0);
            }

            if (game.getGameStatus() == GameStatus.Lost) {
                JOptionPane.showMessageDialog(null,
                        "Wow! You Lose!");
                losses++;
                game.reset();
            } else if (game.getGameStatus() == GameStatus.Won) {
                JOptionPane.showMessageDialog(null,
                        "Bravo! You Win!");
                wins++;
                game.reset();
            }
        }
    }

    private class theMouseListener implements MouseListener {

        @Override
        public void mouseClicked(MouseEvent e) {

        }

        @Override
        public void mousePressed(MouseEvent e) {
            if (e.getButton() == MouseEvent.BUTTON1) {
                selectCell(e);
            } else if (e.getButton() == MouseEvent.BUTTON3) {
                toggleCellFlag(e);
            }
        }

        @Override
        public void mouseReleased(MouseEvent e) {

        }

        @Override
        public void mouseEntered(MouseEvent e) {

        }

        @Override
        public void mouseExited(MouseEvent e) {

        }


    }


    /******************************************************************
     * A class that selects a cell and updates wins/losses if that is
     * the result.
     * @param e a Mouse Event for when someone clicks.
     *****************************************************************/
    private void selectCell(MouseEvent e) {
        int rowsAndColumns[] = getLocationOfEvent(e);
        int rows = rowsAndColumns[0];
        int columns = rowsAndColumns[1];
        this.game.select(rows, columns);

        this.wins = getWins();
        this.losses = getLosses();

        winsLabel.setText("wins: " + wins);
        lossesLabel.setText(("losses: " + losses));

    }

    /******************************************************************
     * A class that gets the location of the clicked cell.
     * @param e a Mouse Event for when someone clicks.
     * @return cells an int array that contains cell locations
     *****************************************************************/
    private int[] getLocationOfEvent(MouseEvent e) {
        int[] cells = {0, 0};
        for (int i = 0; i < this.numRows; i++) {
            for (int j = 0; j < this.numRows; j++)
                if (this.board[i][j] == e.getSource()) {
                    cells[0] = i;
                    cells[1] = j;
                    return cells;
                }
        }
        //this should not occur if something triggers a listener
        return null;
    }

    private void toggleCellFlag(MouseEvent e) {
        //getting the location of the cell that we need flag/unflag
        int rowsAndColumns[] = getLocationOfEvent(e);
        int row = rowsAndColumns[0];
        int column = rowsAndColumns[1];
    }
}


