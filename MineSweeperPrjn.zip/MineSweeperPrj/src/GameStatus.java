public enum GameStatus {
    LOST,WON,NOTOVERYET;
}
